from app import app, response
from flask import request
from app.controllers import mataKuliahController

@app.route('/api/matakuliah', methods=['GET', 'POST'])
def matakuliah():
    if request.method == 'GET':
        return mataKuliahController.index()
    elif request.method == 'POST':
        return mataKuliahController.add()
    else:
        return response.METHOD_NOT_ALLOWED([], "Wrong HTTP method")

@app.route('/api/matakuliah/<int:id>', methods=['GET', 'PUT', 'DELETE'])
def matakuliah_by_id(id):
    if request.method == 'PUT':
        return mataKuliahController.edit(id)
    elif request.method == 'GET':
        return mataKuliahController.show(id)
    elif request.method == 'DELETE':
        return mataKuliahController.delete(id)
    else:
        return response.METHOD_NOT_ALLOWED([], "Wrong HTTP method")
