from app import app, response
from flask import request
from app.controllers import kurikulumController, kurikulumLineController

@app.route('/api/kurikulum', methods=['GET', 'POST'])
def kurikulum():
    if request.method == 'GET':
        return kurikulumController.index()
    elif request.method == 'POST':
        return kurikulumController.add()
    else:
        return response.METHOD_NOT_ALLOWED([], "Wrong HTTP method")

@app.route('/api/kurikulum/<int:id>', methods=['GET', 'PUT', 'DELETE'])
def kurikulum_by_id(id):
    if request.method == 'PUT':
        return kurikulumController.edit(id)
    elif request.method == 'GET':
        return kurikulumController.show(id)
    elif request.method == 'DELETE':
        return kurikulumController.delete(id)
    else:
        return response.METHOD_NOT_ALLOWED([], "Wrong HTTP method")

@app.route('/api/kurikulumdata', methods=['GET', 'POST'])
def kurikulumdata():
    if request.method == 'GET':
        return kurikulumLineController.index()
    elif request.method == 'POST':
        return kurikulumLineController.add()
    else:
        return response.METHOD_NOT_ALLOWED([], "Wrong HTTP method")

@app.route('/api/kurikulumdata/<int:id>', methods=['GET', 'PUT', 'DELETE'])
def kurikulumdata_by_id(id):
    if request.method == 'PUT':
        return kurikulumLineController.edit(id)
    elif request.method == 'GET':
        return kurikulumLineController.show(id)
    elif request.method == 'DELETE':
        return kurikulumLineController.delete(id)
    else:
        return response.METHOD_NOT_ALLOWED([], "Wrong HTTP method")

@app.route('/api/kurikulumdata/<int:id>/<int:year>', methods=['GET'])
def kurikulumdata_by_filter(id, year):
    if request.method == 'GET':
        return kurikulumLineController.show_by_filter(id, year)
    else:
        return response.METHOD_NOT_ALLOWED([], "Wrong HTTP method")