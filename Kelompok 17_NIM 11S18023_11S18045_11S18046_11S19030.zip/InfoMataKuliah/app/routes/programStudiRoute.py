from app import app, response
from flask import request
from app.controllers import programStudiController

@app.route('/api/programstudi', methods=['GET', 'POST'])
def programstudi():
    if request.method == 'GET':
        return programStudiController.index()
    elif request.method == 'POST':
        return programStudiController.add()
    else:
        return response.METHOD_NOT_ALLOWED([], "Wrong HTTP method")

@app.route('/api/programstudi/<int:id>', methods=['GET', 'PUT', 'DELETE'])
def programstudi_by_id(id):
    if request.method == 'PUT':
        return programStudiController.edit(id)
    elif request.method == 'GET':
        return programStudiController.show(id)
    elif request.method == 'DELETE':
        return programStudiController.delete(id)
    else:
        return response.METHOD_NOT_ALLOWED([], "Wrong HTTP method")
