# from . import products
from . import programStudiRoute
from . import mataKuliahRoute
from . import kurikulumRoute