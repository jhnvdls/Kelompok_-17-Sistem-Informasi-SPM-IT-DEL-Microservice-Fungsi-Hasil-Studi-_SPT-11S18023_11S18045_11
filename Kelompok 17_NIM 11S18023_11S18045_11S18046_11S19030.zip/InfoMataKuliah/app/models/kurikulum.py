from app import db, Column, Relationship
from datetime import datetime

class MataKuliah(db.Model):
    id = Column(db.Integer, primary_key=True, autoincrement=True)
    code = Column(db.String(16), unique=True)
    name = Column(db.String(16), nullable=False)
    sks = Column(db.Integer)
    kurikulum_line = Relationship('KurikulumLine', backref='mata_kuliah', lazy=True)
    created_at = Column(db.DateTime, default=datetime.utcnow)
    updated_at = Column(db.DateTime, default=datetime.utcnow)

class ProgramStudi(db.Model):
    id = Column(db.Integer, primary_key=True, autoincrement=True)
    name = Column(db.String(16), nullable=False)
    jenjang = Column(db.String(25), nullable=False)
    kurikulum = Relationship('Kurikulum', backref='program_studi',lazy=True)
    created_at = Column(db.DateTime, default=datetime.utcnow)
    updated_at = Column(db.DateTime, default=datetime.utcnow)

class Kurikulum(db.Model):
    id = Column(db.Integer, primary_key=True, autoincrement=True)
    tahun = Column(db.String(4), nullable=False)
    program_studi_id = Column(db.Integer, db.ForeignKey('program_studi.id'))
    kurikulum_line = Relationship('KurikulumLine', backref='kurikulum',lazy=True)
    created_at = Column(db.DateTime, default=datetime.utcnow)
    updated_at = Column(db.DateTime, default=datetime.utcnow)

class KurikulumLine(db.Model):
    id = Column(db.Integer, primary_key=True, autoincrement=True)
    semester = Column(db.Integer)
    kurikulum_id = Column(db.Integer, db.ForeignKey('kurikulum.id'))
    mata_kuliah_id = Column(db.Integer, db.ForeignKey('mata_kuliah.id'))
    created_at = Column(db.DateTime, default=datetime.utcnow)
    updated_at = Column(db.DateTime, default=datetime.utcnow)