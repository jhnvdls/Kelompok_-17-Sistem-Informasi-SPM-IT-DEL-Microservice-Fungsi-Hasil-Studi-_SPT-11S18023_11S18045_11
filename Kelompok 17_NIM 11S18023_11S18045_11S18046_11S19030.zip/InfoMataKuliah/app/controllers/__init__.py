# from . import productsController
from . import programStudiController
from . import mataKuliahController
from . import kurikulumController