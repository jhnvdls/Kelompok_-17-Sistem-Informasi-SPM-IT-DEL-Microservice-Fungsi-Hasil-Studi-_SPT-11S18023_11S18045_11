from flask import request
from app import response, db
from app.models.kurikulum import Kurikulum, KurikulumLine, MataKuliah, ProgramStudi
from sqlalchemy import and_

def index():
    try:
        kurikulumdata = KurikulumLine.query.all()
        if not kurikulumdata:
            return response.NOT_FOUND([],"No kurikulum data found")

        data = transform(kurikulumdata)
        
        return response.OK({
            "kurikulumdata" : data
        }, "All kurikulum data")

    except Exception as e:
        # print(e)
        return response.INTERNAL_SERVER_ERROR([], "Failed to load kurikulum data")
 

def add():
    try:
        value = dict()
        value['semester'] = request.json['semester']
        value['kurikulum_id'] = request.json['kurikulum']
        value['mata_kuliah_id'] = request.json['mataKuliah']
        
        kurikulumdata = KurikulumLine(**value)
        db.session.add(kurikulumdata)
        db.session.commit()

        data = singleTransform(kurikulumdata)

        return response.CREATED({
            "kurikulumdata" : data
        }, "success add kurikulum data")

    except Exception as e:
        print(e)
        return response.INTERNAL_SERVER_ERROR([], "Failed to load kurikulum data")
 

def show(id):
    try:
        kurikulumdata = KurikulumLine.query.filter_by(id=id).first()
        if not kurikulumdata:
            return response.NOT_FOUND([],"No kurikulum found")

        data = singleTransform(kurikulumdata)

        return response.OK({
            "kurikulumdata" : data
        }, "kurikulum by id")
    except Exception as e:
        return response.INTERNAL_SERVER_ERROR([], "Failed to load kurikulum data")
 

def show_by_filter(id, year):
    try:
        id = int(id)
        year = int(year)

        kurikulum = Kurikulum.query.filter_by(id=id, tahun=year).first()

        if not kurikulum:
            return response.NOT_FOUND([],"No kurikulum found")

        kurikulumline = db.session.query(KurikulumLine, Kurikulum, MataKuliah, ProgramStudi). \
            with_entities(KurikulumLine.id, KurikulumLine.semester, MataKuliah.code ,MataKuliah.name, MataKuliah.sks).\
            select_from(KurikulumLine).\
            join(Kurikulum, KurikulumLine.kurikulum_id == Kurikulum.id).\
            join(MataKuliah, KurikulumLine.mata_kuliah_id == MataKuliah.id).\
            join(ProgramStudi, Kurikulum.program_studi_id == ProgramStudi.id).\
            filter(and_(ProgramStudi.id == id, Kurikulum.tahun == year))
        
        if not kurikulumline:
            return response.NOT_FOUND([],"No kurikulum data found")

        arrayMataKuliah = list()
        
        data = dict()
        data['id']= kurikulum.id
        data['created_at']= kurikulum.created_at
        data['updated_at']= kurikulum.updated_at
        data['tahun']= kurikulum.tahun
        data['programStudi'] = {
            'id': kurikulum.program_studi.id,
            'name': kurikulum.program_studi.name,
            'jenjang': kurikulum.program_studi.jenjang,
            'create_at': kurikulum.program_studi.created_at,
            'update_at': kurikulum.program_studi.updated_at,
        }
        data['mataKuliah'] = arrayMataKuliah

        for value in kurikulumline:
            mataKuliah = dict()
            mataKuliah['id']= value[0]
            mataKuliah['semester']= value[1]
            mataKuliah['code']= value[2]
            mataKuliah['name']= value[3]
            mataKuliah['sks']= value[4]
            arrayMataKuliah.append(mataKuliah)

        return response.OK({
            "kurikulumdata" : data
        }, "kurikulum by id and year")

    except Exception as e:
        print(e)
        return response.INTERNAL_SERVER_ERROR([], "Failed to load kurikulum data")
 


def edit(id):
    try:
        kurikulumdata = KurikulumLine.query.filter_by(id=id).first()
        if not kurikulumdata:
            return response.NOT_FOUND([],"No kurikulum data found")

        kurikulum.semester = request.json['semester'].strip()
        kurikulum.mata_kuliah_id = request.json['mataKuliah']
        kurikulum.kurikulum_id = request.json['kurikulum']

        db.session.add(kurikulumdata)
        db.session.commit()

        data = singleTransform(kurikulumdata)

        return response.CREATED({
            "kurikulumdata" : data
        }, "Success edit kurikulum data")
    except Exception as e:
        return response.INTERNAL_SERVER_ERROR([], "Failed to edit kurikulum data")
 

def delete(id):
    try:
        kurikulumdata = KurikulumLine.query.filter_by(id=id).first()
        if not kurikulumdata:
            return response.NO_CONTENT([], "No data deleted")
        
        db.session.delete(kurikulumdata)
        db.session.commit()

        return response.OK([], "Successfully delete data")
    except Exception as e:
        return response.INTERNAL_SERVER_ERROR([], "Failed to delete")
 
def transform(values):
    array = []
    for i in values:
        array.append(singleTransform(i))
    return array
 
def singleTransform(values):
    data = {
        'id': values.id,
        'semester': values.semester,
        'created_at': values.created_at,
        'updated_at': values.updated_at,
        'kurikulum': {
            'id': values.kurikulum.id,
            'tahun': values.kurikulum.tahun,
            'programStudi': values.kurikulum.program_studi.name,
        },
        'mataKuliah': {
            'id': values.mata_kuliah.id,
            'code': values.mata_kuliah.code,
            'name': values.mata_kuliah.name,
            'sks': values.mata_kuliah.sks,
        }
    }
 
    return data