from flask import request
from app import response, db
from app.models.kurikulum import MataKuliah

def index():
    try:
        matakuliah = MataKuliah.query.all()
        if not matakuliah:
            return response.NOT_FOUND([],"No matakuliah found")

        data = transform(matakuliah)
        
        return response.OK({
            "matakuliah" : data
        }, "All matakuliah")
    except Exception as e:
        # print(e)
        return response.INTERNAL_SERVER_ERROR([], "Failed to load matakuliah")

def add():
    try:
        value = dict()
        value['code'] = request.json['code'].strip() 
        value['name'] = request.json['name'].strip()
        value['sks'] = request.json['sks']
        
        matakuliah = MataKuliah(**value)
        db.session.add(matakuliah)
        db.session.commit()

        data = singleTransform(matakuliah)

        return response.CREATED({
            "matakuliah" : data
        }, "success add matakuliah")
    except Exception as e:
        print(e)
        return response.INTERNAL_SERVER_ERROR([], "Failed to load matakuliah")

def show(id):
    try:
        matakuliah = MataKuliah.query.filter_by(id=id).first()
        if not matakuliah:
            return response.NOT_FOUND([],"No matakuliah found")

        data = singleTransform(matakuliah)

        return response.OK({
            "matakuliah" : data
        }, "matakuliah by id")
    except Exception as e:
        return response.INTERNAL_SERVER_ERROR([], "Failed to load matakuliah")

def edit(id):
    try:
        matakuliah = MataKuliah.query.filter_by(id=id).first()
        if not matakuliah:
            return response.NOT_FOUND([],"No matakuliah found")

        matakuliah.code = request.json['code'].strip() 
        matakuliah.name = request.json['name'].strip()
        matakuliah.sks = request.json['sks']

        db.session.add(matakuliah)
        db.session.commit()

        data = singleTransform(matakuliah)

        return response.CREATED({
            "matakuliah" : data
        }, "Success edit matakuliah")

    except Exception as e:
        return response.INTERNAL_SERVER_ERROR([], "Failed to edit matakuliah")

def delete(id):
    try:
        matakuliah = MataKuliah.query.filter_by(id=id).first()
        if not matakuliah:
            return response.NO_CONTENT([], "No data deleted")
        
        db.session.delete(matakuliah)
        db.session.commit()

        return response.OK([], "Successfully delete data")
    except Exception as e:
        return response.INTERNAL_SERVER_ERROR([], "Failed to delete")
 
def transform(values):
    array = []
    for i in values:
        array.append(singleTransform(i))
    return array
 
def singleTransform(values):
    data = {
        'id': values.id,
        'code': values.code,
        'name': values.name,
        'sks': values.sks,
        'created_at': values.created_at,
        'updated_at': values.updated_at,
    }
 
    return data