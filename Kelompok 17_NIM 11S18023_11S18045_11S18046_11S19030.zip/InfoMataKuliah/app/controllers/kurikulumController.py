from flask import request
from app import response, db
from app.models.kurikulum import Kurikulum
 
def index():
    try:
        kurikulum = Kurikulum.query.all()
        if not kurikulum:
            return response.NOT_FOUND([],"No kurikulum found")

        data = transform(kurikulum)
        
        return response.OK({
            "kurikulum" : data
        }, "All kurikulum")

    except Exception as e:
        return response.INTERNAL_SERVER_ERROR([], "Failed to load kurikulum")
 
def add():
    try:
        value = dict()

        value['tahun'] = request.json['tahun'].strip()
        value['program_studi_id'] = request.json['programStudi']
        
        kurikulum = Kurikulum(**value)
        db.session.add(kurikulum)
        db.session.commit()

        data = singleTransform(kurikulum)

        return response.CREATED({
            "kurikulum" : data
        }, "success add kurikulum")
    except Exception as e:
        return response.INTERNAL_SERVER_ERROR([], "Failed to load kurikulum")
 
def show(id):
    try:
        kurikulum = Kurikulum.query.filter_by(id=id).first()
        if not kurikulum:
            return response.NOT_FOUND([],"No kurikulum found")

        data = singleTransform(kurikulum)

        return response.OK({
            "kurikulum" : data
        }, "kurikulum by id")
 
    except Exception as e:
        return response.INTERNAL_SERVER_ERROR([], "Failed to load kurikulum")
 
def edit(id):
    try:

        kurikulum = Kurikulum.query.filter_by(id=id).first()
        if not kurikulum:
            return response.NOT_FOUND([],"No kurikulum found")

        kurikulum.tahun = request.json['tahun'].strip()
        kurikulum.program_studi_id = request.json['programStudi']

        db.session.add(kurikulum)
        db.session.commit()

        data = singleTransform(kurikulum)

        return response.CREATED({
            "kurikulum" : data
        }, "Success edit kurikulum")
    except Exception as e:
        return response.INTERNAL_SERVER_ERROR([], "Failed to edit kurikulum")
 
def delete(id):
    try:
        kurikulum = Kurikulum.query.filter_by(id=id).first()
        if not kurikulum:
            return response.NO_CONTENT([], "No data deleted")
        
        db.session.delete(kurikulum)
        db.session.commit()

        return response.OK([], "Successfully delete data")
    except Exception as e:
        return response.INTERNAL_SERVER_ERROR([], "Failed to delete")
 
def transform(values):
    array = []
    for i in values:
        array.append(singleTransform(i))
    return array
 
def singleTransform(values):
    data = {
        'id': values.id,
        'tahun': values.tahun,
        'created_at': values.created_at,
        'updated_at': values.updated_at,
        'programStudi': {
            'programStudi_id': values.program_studi.id,
            'name': values.program_studi.name,
            'jenjang': values.program_studi.jenjang,
        },
    }
 
    return data