from flask import request
from app import response, db
from app.models.kurikulum import ProgramStudi
 
def index():
    try:
        programstudi = ProgramStudi.query.all()
        if not programstudi:
            return response.NOT_FOUND([],"No program studi found")

        data = transform(programstudi)
        
        return response.OK({
            "programstudi" : data
        }, "All program studi")
    except Exception as e:
        return response.INTERNAL_SERVER_ERROR([], "Failed to load program studi")
 
def add():
    try:
        value = dict()
        value['name'] = request.json['name'].strip()
        value['jenjang'] = request.json['jenjang'].strip()
        
        programstudi = ProgramStudi(**value)
        db.session.add(programstudi)
        db.session.commit()

        data = singleTransform(programstudi)

        return response.CREATED({
            "programstudi" : data
        }, "success add program studi")
    except Exception as e:
        return response.INTERNAL_SERVER_ERROR([], "Failed to load program studi")
 
def show(id):
    try:
        programstudi = ProgramStudi.query.filter_by(id=id).first()
        if not programstudi:
            return response.NOT_FOUND([],"No program studi found")

        data = singleTransform(programstudi)

        return response.OK({
            "programstudi" : data
        }, "program studi by id")
    except Exception as e:
        return response.INTERNAL_SERVER_ERROR([], "Failed to load program studi")
 
def edit(id):
    try:
        programstudi = ProgramStudi.query.filter_by(id=id).first()
        if not programstudi:
            return response.NOT_FOUND([],"No program studi found")

        programstudi.name = request.json['name'].strip()
        programstudi.jenjang = request.json['jenjang'].strip() 

        db.session.add(programstudi)
        db.session.commit()

        data = singleTransform(programstudi)

        return response.CREATED({
            "programstudi" : data
        }, "Success edit program studi")
    except Exception as e:
        return response.INTERNAL_SERVER_ERROR([], "Failed to edit program studi")
 
def delete(id):
    try:
        programstudi = ProgramStudi.query.filter_by(id=id).first()
        if not programstudi:
            return response.NO_CONTENT([], "No data deleted")
        
        db.session.delete(programstudi)
        db.session.commit()

        return response.OK([], "Successfully delete data")
    except Exception as e:
        return response.INTERNAL_SERVER_ERROR([], "Failed to delete")
 
def transform(values):
    array = []
    for i in values:
        array.append(singleTransform(i))
    return array
 
def singleTransform(values):
    data = {
        'id': values.id,
        'name': values.name,
        'jenjang': values.jenjang,
        'created_at': values.created_at,
        'updated_at': values.updated_at,
    }
 
    return data