from flask import Flask
from flask_sqlalchemy import  SQLAlchemy
from config import DevelopmentConfig

# Init App
app = Flask(__name__)
app.config.from_object(DevelopmentConfig)

# Init Database
db = SQLAlchemy(app)
Column = db.Column
Relationship = db.relationship

# Run Server
from app import routes